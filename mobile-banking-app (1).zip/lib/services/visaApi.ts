// Visa Developer Platform API Service
// Structure ready for real API integration - currently uses mock data

export interface Transaction {
  id: string;
  merchant: string;
  amount: number;
  type: 'income' | 'expense';
  status: 'completed' | 'pending';
  date: string;
  time: string;
  icon: string;
  category?: string;
  description?: string;
}

export interface MerchantData {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviews: number;
  image: string;
  price: number;
  discount?: number;
  delivery?: {
    time: string;
    fee: number;
  };
}

export interface PredictionInsight {
  id: string;
  type: 'prediction' | 'alert' | 'offer';
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  actionUrl?: string;
  actionLabel?: string;
  icon: string;
  category?: string;
  priority: 'high' | 'medium' | 'low';
}

// Mock transaction data simulating Visa Transaction Query API
const mockTransactions: Transaction[] = [
  {
    id: 'txn_001',
    merchant: 'Starbucks',
    amount: -6.5,
    type: 'expense',
    status: 'completed',
    date: 'Today',
    time: '9:45 AM',
    icon: '☕',
    category: 'Food & Beverage',
    description: 'Coffee purchase',
  },
  {
    id: 'txn_002',
    merchant: 'Salary Deposit',
    amount: 3500,
    type: 'income',
    status: 'completed',
    date: 'Today',
    time: '6:00 AM',
    icon: '✓',
    category: 'Income',
    description: 'Monthly salary',
  },
  {
    id: 'txn_003',
    merchant: 'Pending Payment',
    amount: -150,
    type: 'expense',
    status: 'pending',
    date: 'Today',
    time: '10:30 AM',
    icon: '⏳',
    category: 'Pending',
    description: 'Authorization pending',
  },
  {
    id: 'txn_004',
    merchant: 'Amazon',
    amount: -45.99,
    type: 'expense',
    status: 'completed',
    date: 'Yesterday',
    time: '2:30 PM',
    icon: '📦',
    category: 'Shopping',
    description: 'Online retail',
  },
  {
    id: 'txn_005',
    merchant: 'Shell Gas',
    amount: -52.3,
    type: 'expense',
    status: 'completed',
    date: 'Yesterday',
    time: '8:15 AM',
    icon: '⛽',
    category: 'Gas & Fuel',
    description: 'Fuel purchase',
  },
  {
    id: 'txn_006',
    merchant: 'Freelance Work',
    amount: 250,
    type: 'income',
    status: 'pending',
    date: 'Yesterday',
    time: '12:00 PM',
    icon: '💼',
    category: 'Income',
    description: 'Freelance project payment',
  },
  {
    id: 'txn_007',
    merchant: 'Whole Foods',
    amount: -125.48,
    type: 'expense',
    status: 'completed',
    date: 'This Week',
    time: 'Dec 15',
    icon: '🛒',
    category: 'Groceries',
    description: 'Grocery shopping',
  },
  {
    id: 'txn_008',
    merchant: 'Netflix',
    amount: -15.99,
    type: 'expense',
    status: 'completed',
    date: 'This Week',
    time: 'Dec 14',
    icon: '🎬',
    category: 'Entertainment',
    description: 'Streaming subscription',
  },
  {
    id: 'txn_009',
    merchant: 'Bonus Deposit',
    amount: 500,
    type: 'income',
    status: 'completed',
    date: 'This Week',
    time: 'Dec 13',
    icon: '🎁',
    category: 'Income',
    description: 'Performance bonus',
  },
];

// Mock merchant recommendations based on transaction history
// Simulates Visa Merchant Search & Offers API
export async function getTransactionHistory(): Promise<Transaction[]> {
  // In production, this would call:
  // GET /visatransactionquery/v2/transactions
  // With headers: Authorization: Bearer {API_KEY}

  return new Promise((resolve) => {
    setTimeout(() => resolve(mockTransactions), 300);
  });
}

export async function getPredictionInsights(
  hasConsent: boolean
): Promise<PredictionInsight[]> {
  // In production, this would call:
  // GET /visapredictions/v1/insights
  // POST /visamerchantlocator/v2/recommended_merchants

  const predictions = [
    {
      id: 'pred_001',
      type: 'prediction' as const,
      title: 'Time for Coffee',
      description: 'Your usual Wednesday morning coffee - order ahead to save 10%',
      timestamp: new Date().toISOString(),
      read: false,
      actionLabel: 'Order Now',
      icon: '☕',
      category: 'Spending Pattern',
      priority: 'medium' as const,
    },
    {
      id: 'pred_002',
      type: 'prediction' as const,
      title: 'Office Supplies Low',
      description:
        'Based on your purchase history, you might need printer ink soon',
      timestamp: new Date(Date.now() - 3600000).toISOString(),
      read: false,
      actionLabel: 'Shop Now',
      icon: '🖨️',
      category: 'Spending Pattern',
      priority: 'low' as const,
    },
    {
      id: 'pred_003',
      type: 'prediction' as const,
      title: 'Gas Station Reminder',
      description: 'Your car typically needs fuel around this time of month',
      timestamp: new Date(Date.now() - 7200000).toISOString(),
      read: true,
      actionLabel: 'Find Stations',
      icon: '⛽',
      category: 'Spending Pattern',
      priority: 'medium' as const,
    },
  ];

  const alerts = [
    {
      id: 'alert_001',
      type: 'alert' as const,
      title: 'Unusual Activity Detected',
      description: 'Large purchase in a new category - review for security',
      timestamp: new Date(Date.now() - 10800000).toISOString(),
      read: false,
      actionLabel: 'Review',
      icon: '🔔',
      category: 'Security',
      priority: 'high' as const,
    },
    {
      id: 'alert_002',
      type: 'offer' as const,
      title: 'Visa Offer: 5x Points on Dining',
      description: 'Earn 5x Rewards Points on restaurant purchases this month',
      timestamp: new Date(Date.now() - 14400000).toISOString(),
      read: true,
      actionLabel: 'View Offer',
      icon: '🍽️',
      category: 'Offers',
      priority: 'low' as const,
    },
  ];

  // Only include predictions if user has given consent to use transaction data
  if (!hasConsent) {
    return alerts;
  }

  return [...predictions, ...alerts];
}

export async function searchMerchants(query: string): Promise<MerchantData[]> {
  // In production, this would call:
  // GET /visamerchantlocator/v2/merchants/search
  // Query params: keyword={query}, distance=10km, limit=10

  const merchants: MerchantData[] = [
    {
      id: 'mrch_001',
      name: 'Premium Coffee Co',
      category: 'Coffee Shop',
      rating: 4.8,
      reviews: 234,
      image: 'https://images.unsplash.com/photo-1495521821757-a1efb6729352?w=300&h=300&fit=crop',
      price: 6.5,
      discount: 10,
      delivery: { time: '5-10 min', fee: 0 },
    },
    {
      id: 'mrch_002',
      name: 'Best Office Supplies',
      category: 'Office Supplies',
      rating: 4.5,
      reviews: 189,
      image: 'https://images.unsplash.com/photo-1577720643272-265fd2f8eb51?w=300&h=300&fit=crop',
      price: 24.99,
      discount: 15,
      delivery: { time: '1-2 hours', fee: 3.99 },
    },
    {
      id: 'mrch_003',
      name: 'Quick Mart Supplies',
      category: 'Office Supplies',
      rating: 4.2,
      reviews: 127,
      image: 'https://images.unsplash.com/photo-1564466809058-bf4114d55352?w=300&h=300&fit=crop',
      price: 22.5,
      discount: 8,
      delivery: { time: '2-3 hours', fee: 2.99 },
    },
  ];

  return new Promise((resolve) => {
    setTimeout(() => resolve(merchants), 500);
  });
}

export async function getRewardsCalculation(amount: number): Promise<{
  basePoints: number;
  bonusPoints: number;
  totalPoints: number;
  redemptionValue: number;
}> {
  // In production, this would call:
  // POST /visarewards/v1/calculate_points
  // Body: { transaction_amount: amount, card_type: 'signature' }

  const basePoints = Math.floor(amount * 1);
  const bonusPoints = Math.floor(amount * 2); // 3x points for this card
  const totalPoints = basePoints + bonusPoints;

  return new Promise((resolve) => {
    setTimeout(
      () =>
        resolve({
          basePoints,
          bonusPoints,
          totalPoints,
          redemptionValue: totalPoints * 0.01, // 1 point = $0.01
        }),
      200
    );
  });
}

export async function processMerchantOffer(
  merchantId: string,
  offerId: string
): Promise<{ success: boolean; message: string }> {
  // In production, this would call:
  // POST /visaoffers/v1/enroll
  // Body: { merchant_id: merchantId, offer_id: offerId }

  return new Promise((resolve) => {
    setTimeout(
      () =>
        resolve({
          success: true,
          message: `Successfully enrolled in offer for ${merchantId}`,
        }),
      400
    );
  });
}
