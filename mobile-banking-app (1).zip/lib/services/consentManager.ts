// Consent Management Service
// Handles user consent for transaction data usage in Shopping Agent

const CONSENT_KEY = 'shopping_agent_consent';
const CONSENT_TIMESTAMP_KEY = 'shopping_agent_consent_timestamp';

export interface ConsentData {
  granted: boolean;
  timestamp: number;
  version: string;
}

/**
 * Check if user has already given consent
 * @returns true if consent was previously given, false if not given, null if never checked
 */
export function getConsentStatus(): boolean | null {
  if (typeof window === 'undefined') return null;

  const consent = localStorage.getItem(CONSENT_KEY);
  if (consent === 'true') return true;
  if (consent === 'false') return false;
  return null;
}

/**
 * Save user consent decision
 * @param granted - true if user accepts, false if user declines
 */
export function setConsentStatus(granted: boolean): void {
  if (typeof window === 'undefined') return;

  localStorage.setItem(CONSENT_KEY, granted ? 'true' : 'false');
  localStorage.setItem(CONSENT_TIMESTAMP_KEY, Date.now().toString());
}

/**
 * Get when consent was given (useful for compliance)
 * @returns timestamp of when consent was set
 */
export function getConsentTimestamp(): number | null {
  if (typeof window === 'undefined') return null;

  const timestamp = localStorage.getItem(CONSENT_TIMESTAMP_KEY);
  return timestamp ? parseInt(timestamp, 10) : null;
}

/**
 * Clear consent and start fresh
 */
export function clearConsent(): void {
  if (typeof window === 'undefined') return;

  localStorage.removeItem(CONSENT_KEY);
  localStorage.removeItem(CONSENT_TIMESTAMP_KEY);
}

/**
 * Get full consent data for analytics/compliance
 */
export function getFullConsentData(): ConsentData | null {
  const granted = getConsentStatus();
  const timestamp = getConsentTimestamp();

  if (granted === null) return null;

  return {
    granted,
    timestamp: timestamp || 0,
    version: '1.0',
  };
}
