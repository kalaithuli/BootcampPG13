'use client';

import { useState } from 'react';
import { HomeTab } from '@/components/tabs/HomeTab';
import { CardsTab } from '@/components/tabs/CardsTab';
import { AccountsTab } from '@/components/tabs/AccountsTab';
import { ActivityTab } from '@/components/tabs/ActivityTab';
import { ShoppingAgentTab } from '@/components/tabs/ShoppingAgentTab';
import { BottomNavigation } from '@/components/BottomNavigation';
import { AppHeader } from '@/components/AppHeader';
import { NotificationsTab } from '@/components/tabs/NotificationsTab'; // Import NotificationsTab

type ActiveTab = 'home' | 'cards' | 'accounts' | 'activity' | 'shop' | 'notifications'; // Update ActiveTab type

export default function Page() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('home');

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* App Container - Mobile sized */}
      <div className="w-full max-w-md mx-auto flex flex-col h-screen bg-white">
        {/* Header */}
        <AppHeader />

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto pb-20">
          {activeTab === 'home' && <HomeTab />}
          {activeTab === 'cards' && <CardsTab />}
          {activeTab === 'accounts' && <AccountsTab />}
          {activeTab === 'activity' && <ActivityTab />}
          {activeTab === 'shop' && <ShoppingAgentTab />}
        </div>

        {/* Bottom Navigation */}
        <BottomNavigation activeTab={activeTab} onTabChange={setActiveTab} />
      </div>
    </div>
  );
}
