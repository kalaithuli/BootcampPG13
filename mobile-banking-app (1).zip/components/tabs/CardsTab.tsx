'use client';

import { useState } from 'react';
import { Lock } from 'lucide-react';

export function CardsTab() {
  const [controls, setControls] = useState({
    online: true,
    contactless: true,
    international: false,
  });

  return (
    <div className="px-4 py-6 space-y-6">
      {/* My Cards Header */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-4">My Cards</h2>

        {/* Card Visual */}
        <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-6 text-white shadow-xl mb-4 h-56 flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 opacity-10">
            <div className="text-6xl font-bold">VISA</div>
          </div>
          <div className="relative z-10">
            <p className="text-sm opacity-75">Visa Signature Rewards</p>
          </div>
          <div className="relative z-10">
            <p className="text-2xl font-mono tracking-wider mb-4">
              •••• •••• •••• 1234
            </p>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-xs opacity-75">Card Holder</p>
                <p className="font-semibold text-lg">XYZ JAIN</p>
              </div>
              <div>
                <p className="text-xs opacity-75">Expires</p>
                <p className="font-mono">12/26</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Rewards Summary */}
      <div className="bg-secondary/20 border border-secondary rounded-xl p-4 space-y-3">
        <div>
          <p className="text-sm text-muted-foreground mb-1">Rewards Points</p>
          <p className="text-3xl font-bold text-foreground">24,580</p>
        </div>
        <div>
          <p className="text-sm text-muted-foreground mb-1">Cash Back Available</p>
          <p className="text-2xl font-bold text-foreground">$245.80</p>
        </div>
        <div className="w-full bg-muted rounded-full h-2">
          <div className="bg-secondary h-2 rounded-full" style={{ width: '65%' }} />
        </div>
        <p className="text-xs text-muted-foreground">Gold Tier - 65% to Platinum</p>
      </div>

      {/* Card Controls */}
      <div className="space-y-4">
        <h3 className="font-semibold text-foreground">Card Controls</h3>
        {[
          {
            key: 'online',
            label: 'Online Transactions',
          },
          {
            key: 'contactless',
            label: 'Contactless Payments',
          },
          {
            key: 'international',
            label: 'International Usage',
          },
        ].map((control) => (
          <div
            key={control.key}
            className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
          >
            <span className="text-sm font-medium text-foreground">
              {control.label}
            </span>
            <button
              onClick={() =>
                setControls((prev) => ({
                  ...prev,
                  [control.key]: !prev[control.key as keyof typeof prev],
                }))
              }
              className={`w-12 h-7 rounded-full transition-colors ${
                controls[control.key as keyof typeof controls]
                  ? 'bg-success'
                  : 'bg-muted'
              }`}
            />
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="space-y-2">
        <button className="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-primary/90 transition-colors">
          View Statements
        </button>
        <button className="w-full bg-muted text-foreground py-3 rounded-xl font-semibold hover:bg-muted/80 transition-colors flex items-center justify-center gap-2">
          <Lock className="w-4 h-4" />
          Report Lost/Stolen
        </button>
        <button className="w-full bg-muted text-foreground py-3 rounded-xl font-semibold hover:bg-muted/80 transition-colors">
          Manage PIN
        </button>
      </div>
    </div>
  );
}
