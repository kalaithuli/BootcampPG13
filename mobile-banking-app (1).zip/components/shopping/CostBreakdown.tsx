'use client';

import { Coins, Gift, Tag } from 'lucide-react';

export function CostBreakdown() {
  const breakdown = [
    {
      label: 'Original price',
      amount: 39.99,
      icon: null,
      color: 'text-muted-foreground',
    },
    {
      label: 'Card rewards (3x points)',
      amount: -3.99,
      icon: Coins,
      color: 'text-success',
    },
    {
      label: 'Visa offers',
      amount: -5.0,
      icon: Gift,
      color: 'text-success',
    },
    {
      label: 'Merchant discount',
      amount: -2.5,
      icon: Tag,
      color: 'text-success',
    },
  ];

  return (
    <div className="px-4 py-4 space-y-3 bg-muted/20">
      {breakdown.map((item, idx) => {
        const Icon = item.icon;
        return (
          <div key={idx} className="flex items-center justify-between">
            <div className="flex items-center gap-2 flex-1">
              {Icon && <Icon className={`w-4 h-4 ${item.color}`} />}
              <span className="text-sm text-foreground">{item.label}</span>
            </div>
            <span className={`text-sm font-semibold ${item.color}`}>
              {item.amount > 0 ? '$' : '-$'}
              {Math.abs(item.amount).toFixed(2)}
            </span>
          </div>
        );
      })}

      {/* Divider */}
      <div className="h-px bg-border my-2" />

      {/* Total */}
      <div className="flex items-center justify-between pt-2">
        <span className="text-sm font-bold text-foreground">Your net cost</span>
        <span className="text-2xl font-bold text-primary">$28.50</span>
      </div>
    </div>
  );
}
