'use client';

import { useState } from 'react';
import { X, ChevronDown, Lock, Truck } from 'lucide-react';
import { ProductCard } from './ProductCard';
import { CostBreakdown } from './CostBreakdown';
import { MerchantInfo } from './MerchantInfo';
import { PaymentSection } from './PaymentSection';
import { AlternativesSection } from './AlternativesSection';

interface ResultsDialogProps {
  onPayment: () => void;
  onClose: () => void;
}

export function ResultsDialog({ onPayment, onClose }: ResultsDialogProps) {
  const [showAlternatives, setShowAlternatives] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(false);

  return (
    <div className="fixed inset-0 bg-black/40 flex items-end z-50 max-w-md mx-auto">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        onClick={onClose}
        aria-label="Close dialog"
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-t-3xl shadow-2xl w-full max-h-[85vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 p-2 hover:bg-muted rounded-lg transition-colors"
          aria-label="Close"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Content */}
        <div className="px-4 pt-8 pb-6 space-y-6">
          {/* Header */}
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">
              ✨ Best Match For You
            </p>
          </div>

          {/* Product Card */}
          <ProductCard />

          {/* Cost Breakdown (Accordion) */}
          <div className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => setShowBreakdown(!showBreakdown)}
              className="w-full flex items-center justify-between p-4 bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <span className="text-sm font-semibold text-foreground">
                How we calculated this
              </span>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  showBreakdown ? 'rotate-180' : ''
                }`}
              />
            </button>
            {showBreakdown && <CostBreakdown />}
          </div>

          {/* Merchant Info */}
          <MerchantInfo />

          {/* Payment Section */}
          <PaymentSection onPayment={onPayment} />

          {/* More Options Section */}
          <div className="border-t border-border pt-4">
            <button
              onClick={() => setShowAlternatives(!showAlternatives)}
              className="w-full flex items-center justify-between p-3 bg-muted/30 hover:bg-muted/50 rounded-lg transition-colors"
            >
              <span className="text-sm font-semibold text-foreground">
                View 3 more options
              </span>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  showAlternatives ? 'rotate-180' : ''
                }`}
              />
            </button>

            {showAlternatives && <AlternativesSection />}
          </div>
        </div>
      </div>
    </div>
  );
}
