'use client';

import { Star } from 'lucide-react';

export function AlternativesSection() {
  const alternatives = [
    {
      name: 'HP 63 Standard Black Ink',
      brand: 'HP',
      image:
        'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=300&q=80',
      netCost: 24.99,
      merchant: 'Amazon',
      merchantLogo: '📦',
      why: 'Better reviews (4.8★)',
      comparison: 'Saves $3.51 less than top pick',
      whyColor: 'bg-blue-100 text-blue-800',
    },
    {
      name: 'Compatible 63XL Cartridge',
      brand: 'Generic',
      image:
        'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=300&q=80',
      netCost: 18.99,
      merchant: 'Walmart',
      merchantLogo: '🏬',
      why: 'Fastest delivery (Same-day)',
      comparison: 'Lower quality, but significant savings',
      whyColor: 'bg-orange-100 text-orange-800',
    },
    {
      name: 'Canon PG-243 Black Ink',
      brand: 'Canon',
      image:
        'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=300&q=80',
      netCost: 32.5,
      merchant: 'Best Buy',
      merchantLogo: '🛍️',
      why: 'Preferred brand match',
      comparison: 'Based on your Canon printer history',
      whyColor: 'bg-purple-100 text-purple-800',
    },
  ];

  return (
    <div className="mt-4 space-y-3">
      {alternatives.map((alt, idx) => (
        <div key={idx} className="bg-white border border-border rounded-lg p-3">
          {/* Product Info Row */}
          <div className="flex gap-3 mb-3">
            {/* Image */}
            <div className="w-20 h-20 bg-muted rounded flex items-center justify-center flex-shrink-0 overflow-hidden">
              <img
                src={alt.image || "/placeholder.svg"}
                alt={alt.name}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>

            {/* Info */}
            <div className="flex-1">
              <p className="text-xs text-muted-foreground font-medium">
                {alt.brand}
              </p>
              <p className="text-sm font-semibold text-foreground mb-2">
                {alt.name}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-foreground">
                  ${alt.netCost.toFixed(2)}
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-sm">{alt.merchantLogo}</span>
                  <span className="text-xs text-muted-foreground">
                    {alt.merchant}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Why This Badge */}
          <div className={`inline-block text-xs font-semibold px-2 py-1 rounded mb-2 ${alt.whyColor}`}>
            {alt.why}
          </div>

          {/* Comparison Note */}
          <p className="text-xs text-muted-foreground mb-3">{alt.comparison}</p>

          {/* Choose Button */}
          <button className="w-full py-2 border border-primary text-primary rounded-lg font-semibold text-sm hover:bg-primary/5 transition-colors">
            Choose This
          </button>
        </div>
      ))}
    </div>
  );
}
