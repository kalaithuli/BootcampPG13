'use client';

interface PredictiveCardsProps {
  onSelect: (item: string) => void;
}

export function PredictiveCards({ onSelect }: PredictiveCardsProps) {
  const predictions = [
    {
      icon: '🔄',
      name: 'Printer Ink',
      detail: 'Last bought 3 weeks ago',
      action: 'Tap to reorder',
      urgency: 'neutral',
    },
    {
      icon: '☕',
      name: 'Lavazza Coffee',
      detail: 'Usual cycle: 2 weeks',
      action: 'Due in 4 days',
      urgency: 'highlight',
    },
    {
      icon: '🐕',
      name: 'Dog Food',
      detail: 'Runs out in 4 days',
      action: 'Reorder now?',
      urgency: 'urgent',
    },
  ];

  return (
    <div>
      <p className="text-xs text-muted-foreground uppercase mb-3 font-semibold">
        Predictions Based on Your History
      </p>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {predictions.map((pred, idx) => (
          <button
            key={idx}
            onClick={() => onSelect(pred.name)}
            className={`flex-shrink-0 w-40 p-4 rounded-lg border transition-all hover:shadow-md ${
              pred.urgency === 'urgent'
                ? 'bg-warning/10 border-warning'
                : pred.urgency === 'highlight'
                  ? 'bg-secondary/20 border-secondary'
                  : 'bg-muted/50 border-border'
            }`}
          >
            <div className="text-3xl mb-2">{pred.icon}</div>
            <h4 className="font-semibold text-foreground text-sm text-left">
              {pred.name}
            </h4>
            <p className="text-xs text-muted-foreground mb-2 text-left">
              {pred.detail}
            </p>
            <p className="text-xs font-medium text-primary text-left">
              {pred.action}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
