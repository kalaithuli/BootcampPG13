'use client';

import { Star } from 'lucide-react';

export function ProductCard() {
  const product = {
    name: 'HP 63XL Black Ink Cartridge',
    brand: 'HP',
    image:
      'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=300&q=80',
    rating: 4.6,
    reviews: 1234,
    originalPrice: 39.99,
    netCost: 28.5,
  };

  const savings = product.originalPrice - product.netCost;

  return (
    <div className="bg-gradient-to-b from-muted/50 to-transparent rounded-xl p-4 space-y-4">
      {/* Product Image */}
      <div className="flex justify-center">
        <div className="w-48 h-48 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
      </div>

      {/* Product Info */}
      <div className="text-center">
        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
          {product.brand}
        </p>
        <h3 className="text-xl font-bold text-foreground mb-2">
          {product.name}
        </h3>

        {/* Rating */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating)
                    ? 'fill-secondary text-secondary'
                    : 'text-muted'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground">
            {product.rating} ({product.reviews.toLocaleString()} reviews)
          </span>
        </div>
      </div>

      {/* Pricing */}
      <div className="bg-white rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Original Price</span>
          <span className="text-sm line-through text-muted-foreground">
            ${product.originalPrice.toFixed(2)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-foreground">NET COST</span>
          <span className="text-3xl font-bold text-primary">
            ${product.netCost.toFixed(2)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">You Save</span>
          <span className="text-sm font-semibold text-white bg-success px-3 py-1 rounded-full">
            ${savings.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
}
