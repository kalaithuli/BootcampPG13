'use client';

import React from "react"

import { Mic, X } from 'lucide-react';
import { PredictiveCards } from './PredictiveCards';
import { InsightsSection } from './InsightsSection';

interface IdleStateProps {
  inputValue: string;
  onInputChange: (value: string) => void;
  onSearch: (query: string) => void;
  onClearInput: () => void;
  onQuickSuggestion: (suggestion: string) => void;
}

export function IdleState({
  inputValue,
  onInputChange,
  onSearch,
  onClearInput,
  onQuickSuggestion,
}: IdleStateProps) {
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      onSearch(inputValue);
    }
  };

  const quickSuggestions = [
    { label: 'Reorder coffee', icon: '☕' },
    { label: 'Office supplies', icon: '📝' },
    { label: 'Best deal on headphones', icon: '🎧' },
    { label: 'Grocery essentials', icon: '🛒' },
  ];

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <h2 className="text-2xl font-bold text-foreground">Visa Shopping</h2>
          <span className="bg-secondary text-foreground text-xs font-bold px-2 py-1 rounded">
            AGENT
          </span>
        </div>
        <p className="text-muted-foreground">What do you need today, XYZ?</p>
      </div>

      {/* Search Input */}
      <div className="relative">
        <input
          type="text"
          placeholder="e.g., I'm running out of printer ink..."
          value={inputValue}
          onChange={(e) => onInputChange(e.target.value)}
          onKeyDown={handleKeyDown}
          className="w-full px-4 py-3 bg-muted border-2 border-muted rounded-xl text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors pr-10"
        />
        <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex gap-2">
          {inputValue && (
            <button
              onClick={onClearInput}
              className="p-1 hover:bg-muted rounded transition-colors"
              aria-label="Clear input"
            >
              <X className="w-4 h-4 text-muted-foreground" />
            </button>
          )}
          <button
            className="p-1 hover:bg-muted rounded transition-colors"
            aria-label="Voice search"
          >
            <Mic className="w-5 h-5 text-primary" />
          </button>
        </div>
      </div>

      {/* Quick Suggestion Chips */}
      <div>
        <p className="text-xs text-muted-foreground uppercase mb-3 font-semibold">
          Quick suggestions
        </p>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {quickSuggestions.map((suggestion) => (
            <button
              key={suggestion.label}
              onClick={() => onQuickSuggestion(suggestion.label)}
              className="flex items-center gap-2 px-3 py-2 bg-muted border border-border rounded-full whitespace-nowrap hover:bg-muted/80 transition-colors text-sm"
            >
              <span>{suggestion.icon}</span>
              <span className="text-foreground">{suggestion.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Predictive Cards */}
      <PredictiveCards onSelect={onQuickSuggestion} />

      {/* Insights Section */}
      <InsightsSection />
    </div>
  );
}
