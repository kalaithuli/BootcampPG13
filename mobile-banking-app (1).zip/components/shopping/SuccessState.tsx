'use client';

import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';

interface SuccessStateProps {
  onClose: () => void;
}

export function SuccessState({ onClose }: SuccessStateProps) {
  const [scale, setScale] = useState(0);
  const [confetti, setConfetti] = useState<
    Array<{ id: number; x: number; y: number; delay: number }>
  >([]);

  useEffect(() => {
    // Animate checkmark
    setScale(1);

    // Generate confetti
    const particles = Array.from({ length: 30 }).map((_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 50 - 50,
      delay: Math.random() * 0.2,
    }));
    setConfetti(particles);

    // Auto dismiss after 3 seconds
    const timer = setTimeout(() => {
      onClose();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 max-w-md mx-auto">
      <div className="bg-white rounded-2xl p-8 text-center w-full mx-4">
        {/* Success Checkmark Animation */}
        <div className="mb-6 flex justify-center">
          <div
            className={`transition-transform duration-500 ${
              scale === 1 ? 'scale-100' : 'scale-0'
            }`}
          >
            <div className="w-20 h-20 bg-success rounded-full flex items-center justify-center">
              <Check className="w-10 h-10 text-white" />
            </div>
          </div>
        </div>

        {/* Confetti Animation */}
        {confetti.map((particle) => (
          <div
            key={particle.id}
            className="fixed pointer-events-none"
            style={{
              left: `${particle.x}%`,
              top: '50%',
              animation: `fall 2s linear ${particle.delay}s forwards`,
            }}
          >
            <div className="text-2xl">
              {['🎉', '✨', '🎊', '⭐'][Math.floor(Math.random() * 4)]}
            </div>
          </div>
        ))}

        {/* Message */}
        <h2 className="text-3xl font-bold text-foreground mb-2">
          Order Placed!
        </h2>

        {/* Order Details */}
        <div className="space-y-2 my-6 text-sm">
          <p className="text-muted-foreground">
            <span className="font-semibold text-foreground">
              HP 63XL Black Ink Cartridge
            </span>
          </p>
          <p className="text-foreground">
            Paid: <span className="font-bold">$28.50</span>
          </p>
          <p className="text-muted-foreground">
            Card: Visa Signature ••••1234
          </p>
          <p className="text-muted-foreground">
            Delivery: <span className="font-semibold">2-3 days</span>
          </p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 mt-6">
          <button className="w-full bg-primary text-white py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors">
            Track Order
          </button>
          <button className="w-full bg-muted text-foreground py-3 rounded-lg font-semibold hover:bg-muted/80 transition-colors">
            Back to Shopping
          </button>
          <button
            onClick={onClose}
            className="w-full text-primary font-semibold hover:underline"
          >
            Done
          </button>
        </div>
      </div>

      <style>{`
        @keyframes fall {
          to {
            transform: translateY(100vh) rotate(360deg);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
}
