'use client';

import { useState } from 'react';
import { Lock, ChevronDown } from 'lucide-react';

interface PaymentSectionProps {
  onPayment: () => void;
}

export function PaymentSection({ onPayment }: PaymentSectionProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showCardSelector, setShowCardSelector] = useState(false);

  const cards = [
    { last4: '1234', type: 'Visa Signature', rewards: '3x points' },
    { last4: '5678', type: 'Visa Platinum', rewards: '2x points' },
  ];

  const handlePayment = async () => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    onPayment();
  };

  return (
    <div className="space-y-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
      {/* Card Selector */}
      <div>
        <button
          onClick={() => setShowCardSelector(!showCardSelector)}
          className="w-full flex items-center justify-between p-3 bg-white rounded-lg border border-border hover:bg-muted transition-colors"
        >
          <div className="text-left">
            <p className="text-xs text-muted-foreground">Payment Card</p>
            <p className="text-sm font-semibold text-foreground">
              {cards[0].type} •••• {cards[0].last4}
            </p>
            <p className="text-xs text-primary">
              Earn {cards[0].rewards} on this purchase
            </p>
          </div>
          <ChevronDown className="w-5 h-5 text-muted-foreground" />
        </button>

        {showCardSelector && (
          <div className="mt-2 bg-white rounded-lg border border-border overflow-hidden">
            {cards.map((card, idx) => (
              <button
                key={idx}
                className="w-full p-3 border-b border-border last:border-b-0 hover:bg-muted transition-colors text-left"
              >
                <p className="text-sm font-semibold text-foreground">
                  {card.type} •••• {card.last4}
                </p>
                <p className="text-xs text-muted-foreground">
                  Earn {card.rewards}
                </p>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Payment Button */}
      <button
        onClick={handlePayment}
        disabled={isLoading}
        className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-white transition-all ${
          isLoading
            ? 'bg-primary/70 cursor-not-allowed'
            : 'bg-primary hover:bg-primary/90 active:scale-95'
        }`}
        aria-label={`Pay ${isLoading ? 'processing' : '$28.50'} with Visa`}
      >
        {isLoading ? (
          <>
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <Lock className="w-4 h-4" />
            <span>Pay $28.50 with Visa ••••1234</span>
          </>
        )}
      </button>

      {/* Security Info */}
      <p className="text-xs text-muted-foreground text-center">
        🔒 Secured by Visa Tokenization
      </p>
    </div>
  );
}
