'use client';

import { useState } from 'react';
import { Bell } from 'lucide-react';
import { NotificationDropdown } from '@/components/NotificationDropdown';

export function AppHeader() {
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const unreadCount = 3; // Mock unread count - you can pass this as a prop if needed

  return (
    <header className="sticky top-0 bg-white border-b border-border px-4 py-4 z-30">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
            <span className="text-white font-bold text-sm">ABC</span>
          </div>
          <h1 className="text-xl font-bold text-foreground">ABC Bank</h1>
        </div>
        <div className="relative">
          <button
            onClick={() => setIsNotificationOpen(!isNotificationOpen)}
            className="p-2 hover:bg-muted rounded-lg transition-colors relative"
            aria-label="Notifications"
          >
            <Bell className="w-6 h-6 text-foreground" />
            {unreadCount > 0 && (
              <span className="absolute top-0 right-0 w-5 h-5 bg-destructive text-white text-xs font-bold rounded-full flex items-center justify-center">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
          <NotificationDropdown
            isOpen={isNotificationOpen}
            onClose={() => setIsNotificationOpen(false)}
          />
        </div>
      </div>
      <p className="text-sm text-muted-foreground mt-2">Good morning, XYZ Jain</p>
    </header>
  );
}
