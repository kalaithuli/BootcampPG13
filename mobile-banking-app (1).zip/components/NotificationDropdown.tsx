'use client';

import { useState, useEffect } from 'react';
import { X, CheckCheck, Trash2 } from 'lucide-react';
import { getConsentStatus } from '@/lib/services/consentManager';
import { getPredictionInsights } from '@/lib/services/visaApi';
import type { PredictionInsight } from '@/lib/services/visaApi';

interface Notification extends PredictionInsight {
  localRead?: boolean;
}

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationDropdown({
  isOpen,
  onClose,
}: NotificationDropdownProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [filter, setFilter] = useState<'all' | 'unread' | 'predictions' | 'alerts'>('all');
  const [hasConsent, setHasConsent] = useState<boolean | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load notifications on dropdown open
  useEffect(() => {
    if (!isOpen) return;

    const loadNotifications = async () => {
      try {
        setIsLoading(true);
        const consentStatus = getConsentStatus();
        setHasConsent(consentStatus ?? false);

        // Fetch predictions from Visa API service
        const insights = await getPredictionInsights(consentStatus ?? false);
        setNotifications(
          insights.map((insight) => ({
            ...insight,
            localRead: insight.read,
          }))
        );
      } catch (error) {
        console.error('[v0] Failed to load notifications:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadNotifications();
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredNotifications = notifications.filter((n) => {
    if (filter === 'unread') return !n.localRead;
    if (filter === 'predictions') return n.type === 'prediction';
    if (filter === 'alerts') return n.type === 'alert';
    return true;
  });

  const unreadCount = notifications.filter((n) => !n.localRead).length;

  const markAsRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, localRead: true } : n))
    );
  };

  const markAllAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, localRead: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'prediction':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'alert':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'offer':
        return 'bg-green-50 text-green-700 border-green-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'prediction':
        return 'Prediction';
      case 'alert':
        return 'Alert';
      case 'offer':
        return 'Offer';
      default:
        return 'Notification';
    }
  };

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 z-40"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Dropdown Panel */}
      <div className="absolute top-full right-0 mt-2 w-96 max-h-96 bg-white rounded-lg shadow-lg border border-border z-50 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-border">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-foreground">Notifications</h2>
            <button
              onClick={onClose}
              className="p-1 hover:bg-muted rounded transition-colors"
            >
              <X className="w-5 h-5 text-foreground" />
            </button>
          </div>

          {/* Filter Tabs */}
          <div className="flex gap-2 overflow-x-auto">
            {[
              { id: 'all', label: 'All' },
              { id: 'unread', label: `Unread (${unreadCount})` },
              { id: 'predictions', label: 'Predictions' },
              { id: 'alerts', label: 'Alerts' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() =>
                  setFilter(f.id as 'all' | 'unread' | 'predictions' | 'alerts')
                }
                className={`px-3 py-1 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
                  filter === f.id
                    ? 'bg-primary text-white'
                    : 'bg-muted text-foreground hover:bg-muted/80'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Mark All as Read Button */}
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="mt-3 flex items-center gap-2 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
            >
              <CheckCheck className="w-4 h-4" />
              Mark all as read
            </button>
          )}
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
              Loading notifications...
            </div>
          ) : filteredNotifications.length > 0 ? (
            <div className="divide-y divide-border">
              {filteredNotifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 hover:bg-muted/30 transition-colors cursor-pointer relative ${
                    !notification.localRead ? 'bg-primary/5' : ''
                  }`}
                  onClick={() => {
                    if (!notification.localRead) {
                      markAsRead(notification.id);
                    }
                  }}
                >
                  <div className="flex gap-3">
                    <div className="text-2xl flex-shrink-0">
                      {notification.icon}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="font-semibold text-sm text-foreground">
                          {notification.title}
                        </h3>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteNotification(notification.id);
                          }}
                          className="p-1 hover:bg-muted rounded transition-colors flex-shrink-0"
                        >
                          <Trash2 className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 mb-2">
                        <span
                          className={`text-xs font-medium px-2 py-0.5 rounded-full border ${getTypeColor(
                            notification.type
                          )}`}
                        >
                          {getTypeLabel(notification.type)}
                        </span>
                        <span
                          className={`text-xs font-medium ${
                            notification.priority === 'high'
                              ? 'text-destructive'
                              : 'text-muted-foreground'
                          }`}
                        >
                          {notification.priority.toUpperCase()}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {new Date(notification.timestamp).toLocaleString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>

                      <p className="text-sm text-muted-foreground mb-2">
                        {notification.description}
                      </p>

                      {notification.actionLabel && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                          }}
                          className="text-xs font-medium text-primary hover:text-primary/80 transition-colors"
                        >
                          {notification.actionLabel} →
                        </button>
                      )}

                      {!notification.localRead && (
                        <div className="absolute right-2 top-1/2 transform -translate-y-1/2 w-2 h-2 bg-primary rounded-full" />
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
              {hasConsent === false && filter === 'predictions'
                ? 'Grant permission to see predictions'
                : 'No notifications'}
            </div>
          )}
        </div>
      </div>
    </>
  );
}
