'use client';

import { useState, useEffect } from 'react';
import { IdleState } from '@/components/shopping/IdleState';
import { ProcessingState } from '@/components/shopping/ProcessingState';
import { ResultsDialog } from '@/components/shopping/ResultsDialog';
import { SuccessState } from '@/components/shopping/SuccessState';
import { ConsentModal } from '@/components/shopping/ConsentModal';
import { getConsentStatus, setConsentStatus } from '@/lib/services/consentManager';

type ShopState = 'idle' | 'processing' | 'results' | 'success' | 'error';

export function ShoppingAgentTab() {
  const [state, setState] = useState<ShopState>('idle');
  const [query, setQuery] = useState('');
  const [inputValue, setInputValue] = useState('');
  const [selectedCardIndex, setSelectedCardIndex] = useState(0);
  const [hasConsent, setHasConsent] = useState<boolean | null>(null);

  // Check if user has already given consent using consent manager
  useEffect(() => {
    const consentStatus = getConsentStatus();
    setHasConsent(consentStatus);
  }, []);

  const handleSearch = (searchQuery: string = inputValue) => {
    if (!searchQuery.trim()) return;
    setQuery(searchQuery);
    setState('processing');
  };

  const handleProcessingComplete = () => {
    setState('results');
  };

  const handlePayment = () => {
    setState('success');
  };

  const handleSuccessClose = () => {
    setState('idle');
    setInputValue('');
    setQuery('');
  };

  const handleQuickSuggestion = (suggestion: string) => {
    setInputValue(suggestion);
    handleSearch(suggestion);
  };

  const handleClearInput = () => {
    setInputValue('');
  };

  const handleConsentGiven = () => {
    setConsentStatus(true);
    setHasConsent(true);
  };

  const handleConsentDeclined = () => {
    setConsentStatus(false);
    setHasConsent(false);
  };

  // Show loading state while checking localStorage
  if (hasConsent === null) {
    return <div className="p-6 text-center text-muted-foreground">Loading...</div>;
  }

  // If no consent, show consent modal
  if (!hasConsent) {
    return (
      <ConsentModal
        onConsent={handleConsentGiven}
        onDecline={handleConsentDeclined}
      />
    );
  }

  return (
    <div className="relative">
      {state === 'idle' && (
        <IdleState
          inputValue={inputValue}
          onInputChange={setInputValue}
          onSearch={handleSearch}
          onClearInput={handleClearInput}
          onQuickSuggestion={handleQuickSuggestion}
        />
      )}

      {state === 'processing' && (
        <ProcessingState
          query={query}
          onComplete={handleProcessingComplete}
        />
      )}

      {state === 'results' && (
        <ResultsDialog
          onPayment={handlePayment}
          onClose={() => setState('idle')}
        />
      )}

      {state === 'success' && (
        <SuccessState onClose={handleSuccessClose} />
      )}

      {state === 'error' && (
        <div className="p-6 text-center">
          <p className="text-red-600 font-semibold mb-4">
            Something went wrong
          </p>
          <button
            onClick={() => {
              setState('idle');
              setInputValue('');
              setQuery('');
            }}
            className="bg-primary text-white px-6 py-2 rounded-lg font-medium hover:bg-primary/90 transition-colors"
          >
            Try Again
          </button>
        </div>
      )}
    </div>
  );
}
