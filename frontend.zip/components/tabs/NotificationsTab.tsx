'use client';

import React from "react"

import { useState } from 'react';
import { Lightbulb, TrendingUp, AlertCircle, Check, X } from 'lucide-react';

interface Notification {
  id: string;
  type: 'insight' | 'prediction' | 'alert';
  title: string;
  description: string;
  timestamp: string;
  icon: React.ReactNode;
  actionable: boolean;
  read: boolean;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'prediction',
    title: 'Coffee Time Prediction',
    description:
      'You usually buy coffee every Thursday at 10 AM. Would you like us to find the best deal today?',
    timestamp: '2 hours ago',
    icon: <div className="text-2xl">☕</div>,
    actionable: true,
    read: false,
  },
  {
    id: '2',
    type: 'insight',
    title: 'Spending Pattern Alert',
    description:
      'Your weekly groceries spending is 15% higher than usual. Consider our grocery deals.',
    timestamp: '4 hours ago',
    icon: <TrendingUp className="w-5 h-5 text-accent" />,
    actionable: true,
    read: false,
  },
  {
    id: '3',
    type: 'prediction',
    title: 'Office Supplies Due',
    description:
      'Based on your history, you usually order office supplies today. We found 3 great options with discounts.',
    timestamp: '6 hours ago',
    icon: <div className="text-2xl">📎</div>,
    actionable: true,
    read: true,
  },
  {
    id: '4',
    type: 'alert',
    title: 'Unusual Purchase Pattern',
    description:
      'Detected unusual spending at an unfamiliar merchant. If this is legitimate, no action needed.',
    timestamp: '1 day ago',
    icon: <AlertCircle className="w-5 h-5 text-warning" />,
    actionable: false,
    read: true,
  },
  {
    id: '5',
    type: 'prediction',
    title: 'Gas Refill Reminder',
    description:
      'You typically fill up gas every 2 weeks. Next station with best rewards is 2 miles away.',
    timestamp: '2 days ago',
    icon: <div className="text-2xl">⛽</div>,
    actionable: true,
    read: true,
  },
  {
    id: '6',
    type: 'insight',
    title: 'Rewards Maximized',
    description:
      'You earned 3x cashback on your streaming subscriptions this month. Total: $4.50',
    timestamp: '3 days ago',
    icon: <Lightbulb className="w-5 h-5 text-success" />,
    actionable: false,
    read: true,
  },
];

export function NotificationsTab() {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [filter, setFilter] = useState('all');

  const filters = ['all', 'unread', 'predictions', 'alerts'];

  const getFilteredNotifications = () => {
    return notifications.filter((n) => {
      if (filter === 'all') return true;
      if (filter === 'unread') return !n.read;
      if (filter === 'predictions') return n.type === 'prediction';
      if (filter === 'alerts')
        return n.type === 'alert' || n.type === 'insight';
      return true;
    });
  };

  const handleMarkAsRead = (id: string) => {
    setNotifications(
      notifications.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const handleDismiss = (id: string) => {
    setNotifications(notifications.filter((n) => n.id !== id));
  };

  const handleMarkAllAsRead = () => {
    setNotifications(notifications.map((n) => ({ ...n, read: true })));
  };

  const filteredNotifications = getFilteredNotifications();
  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="px-4 py-6 space-y-4 pb-24">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-foreground">
            Notifications
          </h2>
          {unreadCount > 0 && (
            <p className="text-sm text-muted-foreground">
              {unreadCount} unread
            </p>
          )}
        </div>
        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllAsRead}
            className="text-xs font-medium text-primary hover:text-primary/80 transition-colors"
          >
            Mark all as read
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
              filter === f
                ? 'bg-primary text-white'
                : 'bg-muted text-foreground hover:bg-muted/80'
            }`}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
      </div>

      {/* Notifications List */}
      {filteredNotifications.length > 0 ? (
        <div className="space-y-3">
          {filteredNotifications.map((notification) => (
            <div
              key={notification.id}
              className={`p-4 rounded-lg border transition-all ${
                notification.read
                  ? 'bg-white border-border hover:bg-muted/30'
                  : 'bg-accent/5 border-accent/30'
              }`}
            >
              <div className="flex gap-3">
                {/* Icon */}
                <div className="flex-shrink-0 mt-1">
                  {typeof notification.icon === 'string' ? (
                    <div className="text-2xl">{notification.icon}</div>
                  ) : (
                    notification.icon
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="font-semibold text-foreground text-sm">
                      {notification.title}
                      {!notification.read && (
                        <span className="inline-block ml-2 w-2 h-2 bg-primary rounded-full" />
                      )}
                    </h3>
                    <span
                      className={`text-xs whitespace-nowrap flex-shrink-0 ${
                        notification.read
                          ? 'text-muted-foreground'
                          : 'text-primary font-medium'
                      }`}
                    >
                      {notification.timestamp}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
                    {notification.description}
                  </p>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2">
                    {notification.actionable && (
                      <button className="text-xs font-medium text-white bg-primary px-3 py-1.5 rounded-md hover:bg-primary/90 transition-colors">
                        Take Action
                      </button>
                    )}
                    {!notification.read && (
                      <button
                        onClick={() => handleMarkAsRead(notification.id)}
                        className="text-xs font-medium text-primary px-3 py-1.5 rounded-md hover:bg-primary/10 transition-colors flex items-center gap-1"
                      >
                        <Check className="w-3 h-3" />
                        Read
                      </button>
                    )}
                    <button
                      onClick={() => handleDismiss(notification.id)}
                      className="text-xs font-medium text-muted-foreground px-3 py-1.5 rounded-md hover:bg-muted transition-colors flex items-center gap-1"
                    >
                      <X className="w-3 h-3" />
                      Dismiss
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="text-4xl mb-3">🎉</div>
          <p className="text-foreground font-medium mb-1">All caught up!</p>
          <p className="text-sm text-muted-foreground">
            {filter === 'unread'
              ? 'No unread notifications'
              : 'No notifications to show'}
          </p>
        </div>
      )}
    </div>
  );
}
