'use client';

import { ArrowUpRight, ArrowDownLeft, MoreHorizontal } from 'lucide-react';

const mockTransactions = [
  {
    id: 1,
    merchant: 'Starbucks',
    date: 'Today, 9:45 AM',
    amount: -6.5,
    icon: '☕',
  },
  {
    id: 2,
    merchant: 'Salary Deposit',
    date: 'Today, 6:00 AM',
    amount: 3500,
    icon: '✓',
  },
  {
    id: 3,
    merchant: 'Amazon',
    date: 'Yesterday, 2:30 PM',
    amount: -45.99,
    icon: '📦',
  },
  {
    id: 4,
    merchant: 'Shell Gas',
    date: 'Yesterday, 8:15 AM',
    amount: -52.3,
    icon: '⛽',
  },
];

export function HomeTab() {
  return (
    <div className="px-4 py-6 space-y-6">
      {/* Account Balance Card */}
      <div className="bg-gradient-to-br from-primary to-primary/90 rounded-2xl p-6 text-white shadow-lg">
        <p className="text-sm opacity-90 mb-2">Total Balance</p>
        <h2 className="text-4xl font-bold mb-4">$12,458.50</h2>
        <div className="flex items-center gap-2 text-sm">
          <span className="text-success">+2.5%</span>
          <span className="opacity-75">this month</span>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: 'Transfer', icon: '→' },
          { label: 'Pay Bills', icon: '📄' },
          { label: 'Deposit', icon: '+' },
          { label: 'More', icon: '⋯' },
        ].map((action) => (
          <button
            key={action.label}
            className="bg-muted p-4 rounded-xl hover:bg-muted/80 transition-colors flex flex-col items-center gap-2"
          >
            <span className="text-lg">{action.icon}</span>
            <span className="text-xs text-foreground font-medium">
              {action.label}
            </span>
          </button>
        ))}
      </div>

      {/* Recent Transactions */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">
            Recent Transactions
          </h3>
          <button className="text-primary text-sm font-medium hover:underline">
            See All
          </button>
        </div>

        <div className="space-y-3">
          {mockTransactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-3 bg-muted/30 rounded-lg hover:bg-muted/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="text-2xl">{transaction.icon}</div>
                <div>
                  <p className="font-medium text-foreground text-sm">
                    {transaction.merchant}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {transaction.date}
                  </p>
                </div>
              </div>
              <span
                className={`font-semibold text-sm ${
                  transaction.amount > 0
                    ? 'text-success'
                    : 'text-foreground'
                }`}
              >
                {transaction.amount > 0 ? '+' : ''}${Math.abs(transaction.amount).toFixed(2)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
