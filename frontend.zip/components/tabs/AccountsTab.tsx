'use client';

import { Send } from 'lucide-react';

export function AccountsTab() {
  return (
    <div className="px-4 py-6 space-y-6">
      <h2 className="text-2xl font-bold text-foreground">My Accounts</h2>

      {/* Account Cards */}
      <div className="space-y-3">
        {/* Checking Account */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 border border-blue-200 rounded-xl p-4">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Checking Account
              </p>
              <p className="text-sm font-mono text-muted-foreground">(•••• 4567)</p>
            </div>
          </div>
          <p className="text-2xl font-bold text-foreground mb-2">$8,450.25</p>
          <p className="text-xs text-muted-foreground">Available Balance</p>
        </div>

        {/* Savings Account */}
        <div className="bg-gradient-to-br from-green-50 to-green-100 border border-green-200 rounded-xl p-4">
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wide">
                Savings Account
              </p>
              <p className="text-sm font-mono text-muted-foreground">(•••• 8901)</p>
            </div>
          </div>
          <p className="text-2xl font-bold text-foreground mb-2">$4,008.25</p>
          <p className="text-xs text-muted-foreground">Interest Rate: 2.5% APY</p>
        </div>
      </div>

      {/* Transfer Section */}
      <div className="space-y-3">
        <h3 className="font-semibold text-foreground">Quick Transfer</h3>
        <button className="w-full bg-primary text-white py-3 rounded-xl font-semibold hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
          <Send className="w-4 h-4" />
          Between My Accounts
        </button>
        <button className="w-full bg-muted text-foreground py-3 rounded-xl font-semibold hover:bg-muted/80 transition-colors">
          To Other Banks
        </button>
      </div>

      {/* Recent Activity */}
      <div>
        <h3 className="font-semibold text-foreground mb-3">Recent Activity</h3>
        <div className="space-y-2">
          {[
            {
              type: 'deposit',
              desc: 'Salary Deposit',
              amount: '+$3,500.00',
              date: 'Today',
            },
            {
              type: 'transfer',
              desc: 'Transfer to Savings',
              amount: '-$500.00',
              date: 'Dec 15',
            },
            {
              type: 'withdraw',
              desc: 'ATM Withdrawal',
              amount: '-$100.00',
              date: 'Dec 14',
            },
          ].map((activity, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-3 bg-muted/30 rounded-lg"
            >
              <div>
                <p className="text-sm font-medium text-foreground">
                  {activity.desc}
                </p>
                <p className="text-xs text-muted-foreground">{activity.date}</p>
              </div>
              <span
                className={`font-semibold text-sm ${
                  activity.amount.startsWith('+')
                    ? 'text-success'
                    : 'text-foreground'
                }`}
              >
                {activity.amount}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
