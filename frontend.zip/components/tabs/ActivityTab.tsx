'use client';

import { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import { getTransactionHistory } from '@/lib/services/visaApi';
import type { Transaction } from '@/lib/services/visaApi';

// Group transactions by date
const groupTransactionsByDate = (transactions: Transaction[]) => {
  const groups: Record<string, Transaction[]> = {};
  transactions.forEach((txn) => {
    if (!groups[txn.date]) {
      groups[txn.date] = [];
    }
    groups[txn.date].push(txn);
  });
  return Object.entries(groups).map(([date, txns]) => ({ date, transactions: txns }));
};

const mockTransactions = [
  {
    date: 'Today',
    transactions: [
      {
        merchant: 'Starbucks',
        amount: -6.5,
        time: '9:45 AM',
        icon: '☕',
        type: 'expense',
        status: 'completed',
      },
      {
        merchant: 'Salary Deposit',
        amount: 3500,
        time: '6:00 AM',
        icon: '✓',
        type: 'income',
        status: 'completed',
      },
      {
        merchant: 'Pending Payment',
        amount: -150,
        time: '10:30 AM',
        icon: '⏳',
        type: 'expense',
        status: 'pending',
      },
    ],
  },
  {
    date: 'Yesterday',
    transactions: [
      {
        merchant: 'Amazon',
        amount: -45.99,
        time: '2:30 PM',
        icon: '📦',
        type: 'expense',
        status: 'completed',
      },
      {
        merchant: 'Shell Gas',
        amount: -52.3,
        time: '8:15 AM',
        icon: '⛽',
        type: 'expense',
        status: 'completed',
      },
      {
        merchant: 'Freelance Work',
        amount: 250,
        time: '12:00 PM',
        icon: '💼',
        type: 'income',
        status: 'pending',
      },
    ],
  },
  {
    date: 'This Week',
    transactions: [
      {
        merchant: 'Whole Foods',
        amount: -125.48,
        time: 'Dec 15',
        icon: '🛒',
        type: 'expense',
        status: 'completed',
      },
      {
        merchant: 'Netflix',
        amount: -15.99,
        time: 'Dec 14',
        icon: '🎬',
        type: 'expense',
        status: 'completed',
      },
      {
        merchant: 'Bonus Deposit',
        amount: 500,
        time: 'Dec 13',
        icon: '🎁',
        type: 'income',
        status: 'completed',
      },
    ],
  },
];

export function ActivityTab() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load transactions from Visa API on mount
  useEffect(() => {
    const loadTransactions = async () => {
      try {
        setIsLoading(true);
        const data = await getTransactionHistory();
        setTransactions(data);
      } catch (error) {
        console.error('[v0] Failed to load transactions:', error);
        // Fallback to mock data if API fails
        setTransactions(mockTransactions);
      } finally {
        setIsLoading(false);
      }
    };

    loadTransactions();
  }, []);

  const filters = ['all', 'income', 'expense', 'pending'];

  // Filter transactions based on active filter and search query
  const getFilteredTransactions = () => {
    return groupTransactionsByDate(transactions)
      .map((group) => ({
        ...group,
        transactions: group.transactions.filter((t) => {
          const matchesFilter =
            activeFilter === 'all' ||
            (activeFilter === 'income' && t.type === 'income') ||
            (activeFilter === 'expense' && t.type === 'expense') ||
            (activeFilter === 'pending' && t.status === 'pending');

          const matchesSearch =
            searchQuery === '' ||
            t.merchant
              .toLowerCase()
              .includes(searchQuery.toLowerCase());

          return matchesFilter && matchesSearch;
        }),
      }))
      .filter((group) => group.transactions.length > 0);
  };

  const filteredTransactions = getFilteredTransactions();

  return (
    <div className="px-4 py-6 space-y-6">
      <h2 className="text-2xl font-bold text-foreground">
        Transaction History
      </h2>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Search transactions..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2 bg-muted border border-border rounded-lg text-foreground placeholder-muted-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {filters.map((filter) => (
          <button
            key={filter}
            onClick={() => setActiveFilter(filter)}
            className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              activeFilter === filter
                ? 'bg-primary text-white'
                : 'bg-muted text-foreground hover:bg-muted/80'
            }`}
          >
            {filter.charAt(0).toUpperCase() + filter.slice(1)}
          </button>
        ))}
      </div>

      {/* Transactions Grouped by Date */}
      {filteredTransactions.length > 0 ? (
        <div className="space-y-6">
          {filteredTransactions.map((group) => (
            <div key={group.date}>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase mb-3">
                {group.date}
              </h3>
              <div className="space-y-2">
                {group.transactions.map((transaction, idx) => (
                  <div
                    key={idx}
                    className={`flex items-center justify-between p-4 rounded-lg hover:bg-muted/50 transition-colors ${
                      transaction.status === 'pending'
                        ? 'bg-warning/10 border border-warning/20'
                        : 'bg-muted/30'
                    }`}
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <div className="text-2xl">{transaction.icon}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-semibold text-foreground">
                            {transaction.merchant}
                          </p>
                          {transaction.status === 'pending' && (
                            <span className="px-2 py-0.5 bg-warning/20 text-warning text-xs font-medium rounded-full">
                              Pending
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {transaction.time}
                        </p>
                      </div>
                    </div>
                    <span
                      className={`text-sm font-bold ${
                        transaction.type === 'income'
                          ? 'text-success'
                          : 'text-foreground'
                      }`}
                    >
                      {transaction.amount > 0 ? '+' : ''}
                      ${Math.abs(transaction.amount).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <p className="text-muted-foreground text-sm">
            No transactions found for this filter
          </p>
        </div>
      )}
    </div>
  );
}
