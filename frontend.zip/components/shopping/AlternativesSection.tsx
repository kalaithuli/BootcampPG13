'use client';

import { Star } from 'lucide-react';

export interface Alternative {
  name: string;
  brand: string;
  image: string;
  basePrice: number;
  merchant: string;
  merchantLogo: string;
  why: string;
  comparison: string;
  whyColor: string;
  merchant_id?: string;
  rating?: number;
  reviews?: number;
  productUrl?: string;
}

interface AlternativesSectionProps {
  alternatives: Alternative[];
  onSelectAlternative: (alternative: Alternative) => void;
  isSelected?: (product: Alternative) => boolean;
}

export function AlternativesSection({
  alternatives,
  onSelectAlternative,
  isSelected,
}: AlternativesSectionProps) {
  return (
    <div className="mt-4 space-y-3">
      {alternatives.map((alt, idx) => (
        <button
          key={idx}
          onClick={() => onSelectAlternative(alt)}
          className={`w-full bg-white border rounded-lg p-4 transition-all hover:shadow-md ${
            isSelected?.(alt)
              ? 'border-primary bg-primary/5 shadow-md'
              : 'border-border hover:border-primary/50'
          }`}
        >
          {/* Product Info Row */}
          <div className="flex gap-3 mb-3">
            {/* Image */}
            <div className="w-20 h-20 bg-muted rounded flex items-center justify-center flex-shrink-0 overflow-hidden">
              <img
                src={alt.image || '/placeholder.svg'}
                alt={alt.name}
                className="w-full h-full object-cover"
                loading="lazy"
              />
            </div>

            {/* Info */}
            <div className="flex-1 text-left">
              <p className="text-xs text-muted-foreground font-medium">
                {alt.brand}
              </p>
              <p className="text-sm font-semibold text-foreground mb-2">
                {alt.name}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-foreground">
                  ${alt.basePrice.toFixed(2)}
                </span>
                <div className="flex items-center gap-1">
                  <span className="text-sm">{alt.merchantLogo}</span>
                  <span className="text-xs text-muted-foreground">
                    {alt.merchant}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Why This Badge */}
          <div
            className={`inline-block text-xs font-semibold px-2 py-1 rounded mb-2 ${alt.whyColor}`}
          >
            {alt.why}
          </div>

          {/* Comparison Note */}
          <p className="text-xs text-muted-foreground mb-3 text-left">
            {alt.comparison}
          </p>

          {/* Choose Button */}
          <div className="text-sm font-semibold text-primary hover:text-primary/80 transition-colors">
            {isSelected?.(alt) ? '✓ Selected' : 'Choose This'}
          </div>
        </button>
      ))}
    </div>
  );
}
