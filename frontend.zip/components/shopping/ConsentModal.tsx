'use client';

import { X } from 'lucide-react';

interface ConsentModalProps {
  onConsent: () => void;
  onDecline: () => void;
}

export function ConsentModal({ onConsent, onDecline }: ConsentModalProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-sm w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-primary to-primary/80 text-white p-6 flex items-start justify-between">
          <div>
            <h2 className="text-xl font-bold">Permission Required</h2>
            <p className="text-white/80 text-sm mt-1">
              AI Shopping Assistant Access
            </p>
          </div>
          <button
            onClick={onDecline}
            className="text-white/60 hover:text-white transition-colors flex-shrink-0 ml-4"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Description */}
          <div className="space-y-3">
            <p className="text-foreground text-sm leading-relaxed">
              The AI Shopping Assistant needs access to your transaction data to:
            </p>
            <ul className="space-y-2">
              <li className="flex gap-3 text-sm text-foreground">
                <span className="text-success text-lg leading-none">✓</span>
                <span>
                  Analyze your spending patterns and preferences
                </span>
              </li>
              <li className="flex gap-3 text-sm text-foreground">
                <span className="text-success text-lg leading-none">✓</span>
                <span>
                  Find personalized product recommendations
                </span>
              </li>
              <li className="flex gap-3 text-sm text-foreground">
                <span className="text-success text-lg leading-none">✓</span>
                <span>
                  Optimize rewards and cashback opportunities
                </span>
              </li>
              <li className="flex gap-3 text-sm text-foreground">
                <span className="text-success text-lg leading-none">✓</span>
                <span>
                  Display predictive shopping suggestions
                </span>
              </li>
            </ul>
          </div>

          {/* Terms & Conditions */}
          <div className="bg-muted/50 rounded-lg p-4 border border-border">
            <h3 className="font-semibold text-sm text-foreground mb-3">
              Terms & Conditions
            </h3>
            <div className="text-xs text-muted-foreground space-y-2 leading-relaxed">
              <p>
                <strong>Data Privacy:</strong> Your transaction data is
                encrypted and processed securely. We do not share your data
                with third parties.
              </p>
              <p>
                <strong>AI Processing:</strong> Your data is used only for
                shopping recommendations. You can revoke access anytime from
                settings.
              </p>
              <p>
                <strong>Consent Duration:</strong> This permission applies to
                all future shopping sessions unless you change it.
              </p>
              <p>
                <strong>Compliance:</strong> We comply with all financial data
                protection regulations and industry standards.
              </p>
            </div>
          </div>

          {/* Security Note */}
          <div className="bg-accent/10 rounded-lg p-3 border border-accent/20">
            <p className="text-xs text-foreground">
              <strong>🔒 Secure:</strong> Your data stays encrypted and on-device.
              Only aggregated patterns are used for recommendations.
            </p>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-2">
            <button
              onClick={onDecline}
              className="flex-1 px-4 py-3 rounded-lg border border-border text-foreground font-medium hover:bg-muted transition-colors"
            >
              Decline
            </button>
            <button
              onClick={onConsent}
              className="flex-1 px-4 py-3 rounded-lg bg-primary text-white font-medium hover:bg-primary/90 transition-colors"
            >
              I Agree & Continue
            </button>
          </div>

          <p className="text-xs text-center text-muted-foreground">
            You can always change this in Settings
          </p>
        </div>
      </div>
    </div>
  );
}
