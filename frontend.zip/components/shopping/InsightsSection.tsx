'use client';

export function InsightsSection() {
  const insights = [
    {
      icon: '📉',
      title: 'This month: 20% less on groceries',
      detail: 'You saved $45.50',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
    },
    {
      icon: '☕',
      title: 'Your coffee pattern',
      detail: 'Daily purchases 8-9 AM',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
    },
    {
      icon: '✈️',
      title: 'Travel purchases spike 2x/year',
      detail: 'Next predicted: June 2024',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
    },
  ];

  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <h3 className="text-sm font-semibold text-foreground uppercase">
          Your Shopping Insights
        </h3>
        <span className="text-lg">✨</span>
      </div>
      <div className="space-y-2">
        {insights.map((insight, idx) => (
          <div
            key={idx}
            className={`p-4 rounded-lg border ${insight.bgColor} ${insight.borderColor} hover:shadow-md transition-all cursor-pointer`}
          >
            <div className="flex items-start gap-3">
              <span className="text-2xl flex-shrink-0">{insight.icon}</span>
              <div className="text-left">
                <p className="font-semibold text-foreground text-sm">
                  {insight.title}
                </p>
                <p className="text-xs text-muted-foreground">
                  {insight.detail}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
