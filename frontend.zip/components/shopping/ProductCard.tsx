'use client';

import { Star, ExternalLink } from 'lucide-react';
import type { Alternative } from './AlternativesSection';

interface ProductCardProps {
  product?: Alternative;
  cardRewardsPercent?: number;
  cardOfferPercent?: number;
  cardDiscountPercent?: number;
}

export function ProductCard({
  product: productProp,
  cardRewardsPercent = 10,
  cardOfferPercent = 12.5,
  cardDiscountPercent = 6.25,
}: ProductCardProps) {
  const product = productProp || {
    name: 'Premium Wireless Headphones',
    brand: 'HP',
    image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=300&q=80',
    basePrice: 39.99,
    merchant: 'Amazon Prime',
    merchantLogo: '📦',
    why: 'Best match for your printer',
    comparison: '$28.50 net cost after rewards & offers',
    whyColor: 'bg-green-100 text-green-800',
    rating: 4.6,
    reviews: 1234,
    productUrl: 'https://www.amazon.com',
  };

  const rating = product.rating || 4.6;
  const reviews = product.reviews || 1234;
  const productUrl = product.productUrl || 'https://www.amazon.com';

  // Calculate net cost based on card benefits
  const basePrice = product.basePrice;
  const cardRewards = (basePrice * cardRewardsPercent) / 100;
  const visaOffers = (basePrice * cardOfferPercent) / 100;
  const merchantDiscount = (basePrice * cardDiscountPercent) / 100;
  const netCost = basePrice - cardRewards - visaOffers - merchantDiscount;

  const savings = product.basePrice - netCost;

  return (
    <div className="bg-gradient-to-b from-muted/50 to-transparent rounded-xl p-4 space-y-4">
      {/* Product Image */}
      <div className="flex justify-center">
        <div className="w-48 h-48 bg-muted rounded-lg flex items-center justify-center overflow-hidden">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>
      </div>

      {/* Product Info */}
      <div className="text-center">
        <p className="text-xs text-muted-foreground uppercase tracking-wide mb-1">
          {product.brand}
        </p>
        <h3 className="text-xl font-bold text-foreground mb-2">
          {product.name}
        </h3>

        {/* Merchant & Why */}
        <div className="flex items-center justify-center gap-2 mb-3">
          <span className="text-lg">{product.merchantLogo}</span>
          <span className="text-sm text-muted-foreground">{product.merchant}</span>
        </div>

        <div className={`inline-block text-xs font-semibold px-2 py-1 rounded mb-3 ${product.whyColor}`}>
          {product.why}
        </div>

        {/* Rating */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <div className="flex items-center gap-1">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(rating)
                    ? 'fill-secondary text-secondary'
                    : 'text-muted'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-muted-foreground">
            {rating} ({reviews.toLocaleString()} reviews)
          </span>
        </div>
      </div>

      {/* View on Merchant Button */}
      <a
        href={productUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="inline-flex items-center justify-center gap-2 w-full py-2 px-4 text-sm font-semibold text-primary border border-primary rounded-lg hover:bg-primary/10 transition-colors"
      >
        <span>View on {product.merchant.split(' ')[0]}</span>
        <ExternalLink className="w-4 h-4" />
      </a>

      {/* Pricing */}
      <div className="bg-white rounded-lg p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Original Price</span>
          <span className="text-sm line-through text-muted-foreground">
            ${product.basePrice.toFixed(2)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-lg font-bold text-foreground">NET COST</span>
          <span className="text-3xl font-bold text-primary">
            ${netCost.toFixed(2)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">You Save</span>
          <span className="text-sm font-semibold text-white bg-success px-3 py-1 rounded-full">
            ${savings.toFixed(2)}
          </span>
        </div>
      </div>
    </div>
  );
}
