'use client';

import { useEffect, useState } from 'react';
import { Check } from 'lucide-react';

interface ProcessingStateProps {
  query: string;
  onComplete: () => void;
}

interface Step {
  id: number;
  label: string;
  status: 'pending' | 'processing' | 'complete';
}

export function ProcessingState({ query, onComplete }: ProcessingStateProps) {
  const [steps, setSteps] = useState<Step[]>([
    { id: 1, label: 'Processing your request...', status: 'processing' },
    { id: 2, label: 'Analyzing transaction history...', status: 'pending' },
    { id: 3, label: 'Comparing prices across merchants...', status: 'pending' },
    { id: 4, label: 'Calculating card rewards & offers...', status: 'pending' },
    { id: 5, label: 'Finding your best match...', status: 'pending' },
  ]);
  const [progress, setProgress] = useState(20);

  useEffect(() => {
    const interval = setInterval(() => {
      setSteps((prevSteps) => {
        const newSteps = [...prevSteps];
        const processingIndex = newSteps.findIndex(
          (s) => s.status === 'processing'
        );

        if (processingIndex !== -1) {
          newSteps[processingIndex].status = 'complete';
          if (processingIndex < newSteps.length - 1) {
            newSteps[processingIndex + 1].status = 'processing';
          }
        }

        return newSteps;
      });

      setProgress((prev) => Math.min(prev + 20, 100));
    }, 500);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress === 100) {
      const timer = setTimeout(() => {
        onComplete();
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [progress, onComplete]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 max-w-md mx-auto">
      <div className="bg-white rounded-2xl p-8 w-full mx-4">
        {/* Query Display */}
        <p className="text-xs text-muted-foreground uppercase mb-6 text-center">
          Searching: {query}
        </p>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="w-full bg-muted rounded-full h-2">
            <div
              className="bg-primary h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-xs text-muted-foreground text-right mt-2">
            {progress}%
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-4">
          {steps.map((step) => (
            <div key={step.id} className="flex items-center gap-3">
              <div
                className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                  step.status === 'complete'
                    ? 'bg-success text-white'
                    : step.status === 'processing'
                      ? 'bg-primary'
                      : 'bg-muted'
                }`}
              >
                {step.status === 'complete' ? (
                  <Check className="w-4 h-4" />
                ) : step.status === 'processing' ? (
                  <div
                    className="w-2 h-2 bg-white rounded-full animate-pulse"
                    style={{
                      animation:
                        'pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                    }}
                  />
                ) : (
                  <div className="w-2 h-2 bg-muted-foreground rounded-full" />
                )}
              </div>
              <span
                className={`text-sm ${
                  step.status === 'complete'
                    ? 'text-foreground font-medium'
                    : step.status === 'processing'
                      ? 'text-primary font-medium'
                      : 'text-muted-foreground'
                }`}
              >
                {step.label}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
