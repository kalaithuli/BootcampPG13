'use client';

import { useState } from 'react';
import { Lock, ChevronDown, AlertCircle } from 'lucide-react';

interface Card {
  id: string;
  type: string;
  last4: string;
  rewards: string;
  rewardsPercent: number;
  offerPercent: number;
  discountPercent: number;
  available: boolean;
  reason?: string;
}

interface PaymentSectionProps {
  onPayment: () => void;
  cards: Card[];
  selectedCardIndex: number;
  onCardChange: (index: number) => void;
  netCost: number;
}

export function PaymentSection({
  onPayment,
  cards,
  selectedCardIndex,
  onCardChange,
  netCost,
}: PaymentSectionProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [showCardSelector, setShowCardSelector] = useState(false);

  const currentCard = cards[selectedCardIndex];

  const handlePayment = async () => {
    if (!currentCard.available) return;
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1000));
    onPayment();
  };

  return (
    <div
      className={`space-y-4 border rounded-lg p-4 ${
        currentCard.available
          ? 'bg-blue-50 border-blue-200'
          : 'bg-orange-50 border-orange-200'
      }`}
    >
      {/* Card Selector */}
      <div>
        <button
          onClick={() => setShowCardSelector(!showCardSelector)}
          className={`w-full flex items-center justify-between p-3 bg-white rounded-lg border border-border hover:bg-muted transition-colors ${
            !currentCard.available ? 'opacity-60' : ''
          }`}
        >
          <div className="text-left">
            <p className="text-xs text-muted-foreground">Payment Card</p>
            <p className="text-sm font-semibold text-foreground">
              {currentCard.type} •••• {currentCard.last4}
            </p>
            <p className="text-xs text-primary">
              Earn {currentCard.rewards} on this purchase
            </p>
          </div>
          <ChevronDown className="w-5 h-5 text-muted-foreground" />
        </button>

        {showCardSelector && (
          <div className="mt-2 bg-white rounded-lg border border-border overflow-hidden shadow-lg">
            {cards.map((card, idx) => (
              <button
                key={card.id}
                onClick={() => {
                  onCardChange(idx);
                  setShowCardSelector(false);
                }}
                className={`w-full p-4 border-b border-border last:border-b-0 text-left transition-colors ${
                  idx === selectedCardIndex
                    ? 'bg-primary/10'
                    : 'hover:bg-muted'
                } ${!card.available ? 'opacity-60' : ''}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-foreground">
                      {card.type} •••• {card.last4}
                      {idx === selectedCardIndex && (
                        <span className="ml-2 text-xs bg-primary text-white px-2 py-0.5 rounded-full">
                          Selected
                        </span>
                      )}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Earn {card.rewards}
                    </p>
                    {card.reason && (
                      <p className="text-xs text-orange-700 mt-1 font-medium">
                        {card.reason}
                      </p>
                    )}
                  </div>
                  {!card.available && (
                    <AlertCircle className="w-5 h-5 text-orange-600 flex-shrink-0 ml-2" />
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Unavailable Card Notice */}
      {!currentCard.available && (
        <div className="p-3 bg-orange-100 border border-orange-300 rounded-lg">
          <p className="text-xs text-orange-900 font-medium">
            {currentCard.reason}
          </p>
        </div>
      )}

      {/* Payment Button */}
      <button
        onClick={handlePayment}
        disabled={isLoading || !currentCard.available}
        className={`w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-white transition-all ${
          !currentCard.available
            ? 'bg-muted text-muted-foreground cursor-not-allowed'
            : isLoading
              ? 'bg-primary/70 cursor-not-allowed'
              : 'bg-primary hover:bg-primary/90 active:scale-95'
        }`}
        aria-label={`Pay ${isLoading ? 'processing' : `$${netCost.toFixed(2)}`} with Visa`}
      >
        {!currentCard.available ? (
          <>
            <AlertCircle className="w-4 h-4" />
            <span>Card Unavailable</span>
          </>
        ) : isLoading ? (
          <>
            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            <span>Processing...</span>
          </>
        ) : (
          <>
            <Lock className="w-4 h-4" />
            <span>Pay ${netCost.toFixed(2)} with Visa ••••{currentCard.last4}</span>
          </>
        )}
      </button>

      {/* Security Info */}
      <p className="text-xs text-muted-foreground text-center">
        🔒 Secured by Visa Tokenization
      </p>
    </div>
  );
}
