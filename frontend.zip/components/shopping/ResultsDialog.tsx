'use client';

import { useState } from 'react';
import { X, ChevronDown, Lock, Truck } from 'lucide-react';
import { ProductCard } from './ProductCard';
import { CostBreakdown } from './CostBreakdown';
import { MerchantInfo } from './MerchantInfo';
import { PaymentSection } from './PaymentSection';
import { AlternativesSection, type Alternative } from './AlternativesSection';

interface ResultsDialogProps {
  onPayment: () => void;
  onClose: () => void;
}

export function ResultsDialog({ onPayment, onClose }: ResultsDialogProps) {
  const [showAlternatives, setShowAlternatives] = useState(false);
  const [showBreakdown, setShowBreakdown] = useState(false);
  const [selectedCardIndex, setSelectedCardIndex] = useState(0);
  const [currentProduct, setCurrentProduct] = useState<Alternative>({
    name: 'HP 63XL Premium Black Ink Cartridge',
    brand: 'HP',
    image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=400',
    basePrice: 39.99,
    merchant: 'Amazon Prime',
    merchantLogo: '📦',
    why: 'Best match for your printer',
    comparison: '$28.50 net cost after rewards & offers',
    whyColor: 'bg-green-100 text-green-800',
    rating: 4.6,
    reviews: 1234,
    productUrl: 'https://www.amazon.com/HP-63XL-Black-Cartridge/s',
  });

  // Alternative products
  const alternatives: Alternative[] = [
    {
      name: 'HP 63 Standard Black Ink',
      brand: 'HP',
      image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=400',
      basePrice: 24.99,
      merchant: 'Amazon',
      merchantLogo: '📦',
      why: 'Better reviews (4.8★)',
      comparison: 'Saves $3.51 less than top pick',
      whyColor: 'bg-blue-100 text-blue-800',
      rating: 4.8,
      reviews: 2156,
      productUrl: 'https://www.amazon.com/HP-63-Black-Cartridge/s',
    },
    {
      name: 'Compatible 63XL Cartridge',
      brand: 'Generic',
      image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=400',
      basePrice: 18.99,
      merchant: 'Walmart',
      merchantLogo: '🏬',
      why: 'Fastest delivery (Same-day)',
      comparison: 'Lower quality, but significant savings',
      whyColor: 'bg-orange-100 text-orange-800',
      rating: 3.9,
      reviews: 542,
      productUrl: 'https://www.walmart.com/ip/Compatible-63XL-Cartridge/123456',
    },
    {
      name: 'Canon PG-243 Black Ink',
      brand: 'Canon',
      image: 'https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?w=400',
      basePrice: 32.5,
      merchant: 'Best Buy',
      merchantLogo: '🛍️',
      why: 'Preferred brand match',
      comparison: 'Based on your Canon printer history',
      whyColor: 'bg-purple-100 text-purple-800',
      rating: 4.5,
      reviews: 876,
      productUrl: 'https://www.bestbuy.com/site/Canon-PG-243-Ink/987654',
    },
  ];

  // Card data with different benefits
  const cards = [
    {
      id: 'card1',
      type: 'Visa Signature',
      last4: '1234',
      rewards: '3x points',
      rewardsPercent: 10,
      offerPercent: 12.5,
      discountPercent: 6.25,
      available: true,
    },
    {
      id: 'card2',
      type: 'Visa Platinum',
      last4: '5678',
      rewards: '2x points',
      rewardsPercent: 5,
      offerPercent: 8,
      discountPercent: 4,
      available: true,
    },
    {
      id: 'card3',
      type: 'Visa Infinite',
      last4: '9012',
      rewards: '5x points',
      rewardsPercent: 15,
      offerPercent: 15,
      discountPercent: 8,
      available: false,
      reason: 'Insufficient funds. Move $12.50 here for 2x rewards on premium purchases',
    },
  ];

  const currentCard = cards[selectedCardIndex];

  // Calculate pricing based on selected card and product
  const basePrice = currentProduct?.basePrice || 0;
  const cardRewards = (basePrice * currentCard.rewardsPercent) / 100;
  const visaOffers = (basePrice * currentCard.offerPercent) / 100;
  const merchantDiscount = (basePrice * currentCard.discountPercent) / 100;
  const netCost = basePrice - cardRewards - visaOffers - merchantDiscount;

  return (
    <div className="fixed inset-0 bg-black/40 flex items-end z-50 max-w-md mx-auto">
      {/* Backdrop */}
      <div
        className="absolute inset-0"
        onClick={onClose}
        aria-label="Close dialog"
      />

      {/* Modal Card */}
      <div className="relative bg-white rounded-t-3xl shadow-2xl w-full max-h-[85vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 z-10 p-2 hover:bg-muted rounded-lg transition-colors"
          aria-label="Close"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Content */}
        <div className="px-4 pt-8 pb-6 space-y-6">
          {/* Header */}
          <div className="text-center">
            <p className="text-2xl font-bold text-foreground">
              ✨ Best Match For You
            </p>
          </div>

          {/* Product Card */}
          <ProductCard
            product={currentProduct}
            cardRewardsPercent={currentCard.rewardsPercent}
            cardOfferPercent={currentCard.offerPercent}
            cardDiscountPercent={currentCard.discountPercent}
          />

          {/* Cost Breakdown (Accordion) */}
          <div className="border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => setShowBreakdown(!showBreakdown)}
              className="w-full flex items-center justify-between p-4 bg-muted/30 hover:bg-muted/50 transition-colors"
            >
              <span className="text-sm font-semibold text-foreground">
                How we calculated this
              </span>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  showBreakdown ? 'rotate-180' : ''
                }`}
              />
            </button>
            {showBreakdown && (
              <CostBreakdown
                basePrice={basePrice}
                cardRewards={cardRewards}
                visaOffers={visaOffers}
                merchantDiscount={merchantDiscount}
                netCost={netCost}
                rewardsLabel={currentCard.rewards}
              />
            )}
          </div>

          {/* Merchant Info */}
          <MerchantInfo />

          {/* Payment Section */}
          <PaymentSection
            onPayment={onPayment}
            cards={cards}
            selectedCardIndex={selectedCardIndex}
            onCardChange={setSelectedCardIndex}
            netCost={netCost}
          />

          {/* More Options Section */}
          <div className="border-t border-border pt-4">
            <button
              onClick={() => setShowAlternatives(!showAlternatives)}
              className="w-full flex items-center justify-between p-3 bg-muted/30 hover:bg-muted/50 rounded-lg transition-colors"
            >
              <span className="text-sm font-semibold text-foreground">
                View 3 more options
              </span>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  showAlternatives ? 'rotate-180' : ''
                }`}
              />
            </button>

            {showAlternatives && (
              <AlternativesSection
                alternatives={alternatives}
                onSelectAlternative={setCurrentProduct}
                isSelected={(alt) =>
                  alt.name === currentProduct.name &&
                  alt.basePrice === currentProduct.basePrice
                }
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
