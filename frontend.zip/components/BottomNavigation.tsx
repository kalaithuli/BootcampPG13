'use client';

import {
  Home,
  CreditCard,
  Wallet,
  Clock,
  Sparkles,
  Bell,
} from 'lucide-react';

type ActiveTab = 'home' | 'cards' | 'accounts' | 'activity' | 'shop';

interface BottomNavigationProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
}

export function BottomNavigation({
  activeTab,
  onTabChange,
}: BottomNavigationProps) {
  const tabs = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'cards', label: 'Cards', icon: CreditCard },
    { id: 'accounts', label: 'Accounts', icon: Wallet },
    { id: 'activity', label: 'Activity', icon: Clock },
    { id: 'shop', label: 'Shop', icon: Sparkles },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-border">
      <div className="flex items-center justify-around">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id as ActiveTab)}
              className={`flex-1 flex flex-col items-center justify-center py-3 px-2 gap-1 transition-colors relative group ${
                isActive
                  ? 'text-primary'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
              aria-label={`${tab.label} tab`}
            >
              <div className="relative">
                <Icon className="w-6 h-6" />
                {isActive && (
                  <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full mt-1" />
                )}
              </div>
              <span className="text-xs font-medium">{tab.label}</span>
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
