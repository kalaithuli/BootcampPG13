# ABC Bank Mobile App - Visa API Integration

This document describes the Visa Developer Platform (VDP) API integration for the ABC Bank mobile banking application.

## Architecture Overview

The app uses a service-based architecture with clean separation between UI components and API calls:

```
Components → Services → Visa APIs
   ↓
consentManager.ts (handles user consent)
visaApi.ts (Visa API service layer)
```

## Services

### 1. Consent Manager (`/lib/services/consentManager.ts`)

Handles user consent for transaction data access in the Shopping Agent.

**Functions:**
- `getConsentStatus()` - Check if user has given consent
- `setConsentStatus(granted: boolean)` - Save consent decision
- `getConsentTimestamp()` - Get when consent was given
- `clearConsent()` - Reset consent preference
- `getFullConsentData()` - Get complete consent data for compliance

**Storage:** Uses browser localStorage with key `shopping_agent_consent`

**Usage:**
```typescript
import { getConsentStatus, setConsentStatus } from '@/lib/services/consentManager';

// Check existing consent
const hasConsent = getConsentStatus(); // true | false | null

// Save user decision
setConsentStatus(true); // User accepts
setConsentStatus(false); // User declines
```

### 2. Visa API Service (`/lib/services/visaApi.ts`)

Main service layer for all Visa API interactions.

**Available Functions:**

#### `getTransactionHistory()`
Fetches user transaction history from Visa Transaction Query API.

**Maps to:** `GET /visatransactionquery/v2/transactions`

**Returns:** Array of Transaction objects
```typescript
interface Transaction {
  id: string;
  merchant: string;
  amount: number;
  type: 'income' | 'expense';
  status: 'completed' | 'pending';
  date: string;
  time: string;
  icon: string;
  category?: string;
  description?: string;
}
```

**Usage:**
```typescript
import { getTransactionHistory } from '@/lib/services/visaApi';

const transactions = await getTransactionHistory();
```

#### `getPredictionInsights(hasConsent: boolean)`
Fetches AI-powered predictions based on transaction analysis.

**Maps to:** 
- `GET /visapredictions/v1/insights`
- `POST /visamerchantlocator/v2/recommended_merchants`

**Returns:** Array of PredictionInsight objects
```typescript
interface PredictionInsight {
  id: string;
  type: 'prediction' | 'alert' | 'offer';
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  actionUrl?: string;
  actionLabel?: string;
  icon: string;
  category?: string;
  priority: 'high' | 'medium' | 'low';
}
```

**Behavior:** 
- If `hasConsent === true`: Returns all predictions and alerts
- If `hasConsent === false`: Returns only system alerts and offers (no transaction-based predictions)

**Usage:**
```typescript
import { getPredictionInsights, getConsentStatus } from '@/lib/services/visaApi';

const consentStatus = getConsentStatus();
const insights = await getPredictionInsights(consentStatus ?? false);
```

#### `searchMerchants(query: string)`
Searches for merchants and their offers based on user query.

**Maps to:** `GET /visamerchantlocator/v2/merchants/search`

**Query Parameters:**
- `keyword` - Search query
- `distance` - 10km radius
- `limit` - 10 results

**Returns:** Array of MerchantData objects
```typescript
interface MerchantData {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviews: number;
  image: string;
  price: number;
  discount?: number;
  delivery?: {
    time: string;
    fee: number;
  };
}
```

**Usage:**
```typescript
import { searchMerchants } from '@/lib/services/visaApi';

const results = await searchMerchants('coffee near me');
```

#### `getRewardsCalculation(amount: number)`
Calculates rewards points for a transaction.

**Maps to:** `POST /visarewards/v1/calculate_points`

**Body:**
```json
{
  "transaction_amount": amount,
  "card_type": "signature"
}
```

**Returns:**
```typescript
{
  basePoints: number;
  bonusPoints: number;
  totalPoints: number;
  redemptionValue: number;
}
```

**Usage:**
```typescript
import { getRewardsCalculation } from '@/lib/services/visaApi';

const rewards = await getRewardsCalculation(150.00);
```

#### `processMerchantOffer(merchantId: string, offerId: string)`
Enrolls user in a merchant offer.

**Maps to:** `POST /visaoffers/v1/enroll`

**Body:**
```json
{
  "merchant_id": merchantId,
  "offer_id": offerId
}
```

**Returns:**
```typescript
{
  success: boolean;
  message: string;
}
```

**Usage:**
```typescript
import { processMerchantOffer } from '@/lib/services/visaApi';

const result = await processMerchantOffer('mrch_001', 'offer_123');
```

## Flow: Consent & Data Usage

### First-Time User Flow

1. User navigates to **Shop tab**
2. `ShoppingAgentTab` checks `getConsentStatus()`
3. If `null` (first time), `ConsentModal` is shown
4. User sees:
   - Permission request
   - Data usage explanation
   - Full Terms & Conditions
   - Security/Privacy notes
5. User clicks **"I Agree & Continue"** or **"Decline"**
6. Decision is saved via `setConsentStatus(true|false)`

### Subsequent Visits

1. User navigates to **Shop tab**
2. `getConsentStatus()` returns saved value
3. If `true`: Shopping Agent loads normally
4. If `false`: Shopping Agent shows limited features

### Notifications Integration

1. **NotificationDropdown** checks consent via `getConsentStatus()`
2. Calls `getPredictionInsights(consentStatus)`
3. Vita API filters results based on consent:
   - **With consent**: Shows predictions, alerts, offers
   - **Without consent**: Shows only alerts and offers

## Environment Variables

When adding real API credentials, set these environment variables:

```env
# Visa Developer Platform
NEXT_PUBLIC_VISA_API_KEY=your_api_key_here
NEXT_PUBLIC_VISA_API_URL=https://api.visa.com/v2
NEXT_PUBLIC_USER_ID=your_user_id_here
```

**Note:** `NEXT_PUBLIC_` prefix allows these to be used in browser code. In production, sensitive operations should use a backend proxy.

## Transitioning from Mock Data to Real APIs

Currently, the app uses mock data but is structured for easy migration:

### Step 1: Update the Visa API service (`/lib/services/visaApi.ts`)

Replace each function's mock implementation with real API calls:

```typescript
export async function getTransactionHistory(): Promise<Transaction[]> {
  const response = await fetch(
    `${process.env.NEXT_PUBLIC_VISA_API_URL}/visatransactionquery/v2/transactions`,
    {
      headers: {
        'Authorization': `Bearer ${process.env.NEXT_PUBLIC_VISA_API_KEY}`,
        'Content-Type': 'application/json',
      },
    }
  );

  if (!response.ok) throw new Error('Failed to fetch transactions');
  return response.json();
}
```

### Step 2: Add error handling

Components already have try/catch blocks:

```typescript
try {
  const data = await getTransactionHistory();
  setTransactions(data);
} catch (error) {
  console.error('Failed to load transactions:', error);
  // Fallback to mock data
}
```

### Step 3: Add loading states

All components have `isLoading` state for better UX during API calls.

## Components Using Visa APIs

### 1. ShoppingAgentTab (`/components/tabs/ShoppingAgentTab.tsx`)
- Uses `ConsentModal` for first-time consent
- Uses `getConsentStatus` from consent manager

### 2. ActivityTab (`/components/tabs/ActivityTab.tsx`)
- Calls `getTransactionHistory()` on mount
- Groups and filters transactions by type (income/expense/pending)
- Falls back to mock data if API fails

### 3. NotificationDropdown (`/components/NotificationDropdown.tsx`)
- Calls `getPredictionInsights()` when dropdown opens
- Respects consent status
- Shows loading state during fetch

### 4. IdleState (`/components/shopping/IdleState.tsx`)
- Can call `searchMerchants()` for search queries
- Ready for integration

## Testing

To test with mock data:
1. Run the app - all features work with default mock data
2. Click "Shop" - see consent modal on first visit
3. Accept consent - shopping agent activates
4. Click notification bell - see predictions/alerts respecting consent

To test real APIs:
1. Get Visa VDP credentials from https://developer.visa.com
2. Add environment variables
3. Update `/lib/services/visaApi.ts` functions
4. Test each endpoint individually

## Security Best Practices

1. **Never commit API keys** - Use environment variables
2. **CORS handling** - In production, use a backend proxy for API calls
3. **Data encryption** - Transaction data should be encrypted in transit (HTTPS)
4. **Consent compliance** - Always verify consent before using transaction data
5. **Error logging** - Don't expose API errors to users

## References

- Visa Developer Platform: https://developer.visa.com
- Transaction Query API: https://developer.visa.com/capabilities/transaction_query
- Merchant Locator API: https://developer.visa.com/capabilities/merchant_search
- Predictions API: https://developer.visa.com/capabilities/predictions
- Rewards Calculation: https://developer.visa.com/capabilities/rewards

## Support

For API issues, check:
1. Environment variables are set correctly
2. API credentials are valid
3. API rate limits aren't exceeded
4. Browser console for detailed error messages
